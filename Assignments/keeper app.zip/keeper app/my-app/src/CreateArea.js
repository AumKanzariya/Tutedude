import React, { useState } from "react";
import "./App.css";

function CreateArea(props) {
    const [note, setNote] = useState({
        title: "",
        content: "",
    });

    function handlechange(event) {
        const { name, value } = event.target;
        setNote((prevNote) => {
            return {
                ...prevNote,
                [name]: value,
            };
        });
    }

    function submitNote(event) {
        props.onAdd(note);
        setNote({
            title: "",
            content: "",
        });
        event.preventDefault();
    }

    return (
        <div>
            <form>
                <input
                    className="t"
                    name="title"
                    onChange={handlechange}
                    value={note.title}
                    placeholder="title"
                />
                <textarea
                    name="content"
                    onChange={handlechange}
                    value={note.content}
                    placeholder="take a note..."
                    rows="3"
                />
                <button className="addbutton" onClick={submitNote}>add</button>
            </form>
        </div>
    );
}
export default CreateArea;
